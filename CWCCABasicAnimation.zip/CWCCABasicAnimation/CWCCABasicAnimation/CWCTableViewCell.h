//
//  CWCTableViewCell.h
//  CWCCABasicAnimation
//
//  Created by CWC on 17/8/22.
//  Copyright © 2017年 . All rights reserved.
//

#import <UIKit/UIKit.h>
@class CWCCABasicAnimation;
@class CWCmodel;

@interface CWCTableViewCell : UITableViewCell

/**
 *  <#注释#>
 */
@property (nonatomic, strong) CAShapeLayer *layer0;
/**
 *  <#注释#>
 */
@property (nonatomic, strong) CAShapeLayer *layer1;
/**
 *  <#注释#>
 */
@property (nonatomic, strong) CWCCABasicAnimation *animation;
/**
 *  <#注释#>
 */
@property (nonatomic, assign) NSInteger tag0;

/**
 *  <#注释#>
 */
@property (nonatomic, strong) void(^blockUpdate)(NSString *tag);

/**
 *  <#注释#>
 */
@property (nonatomic, strong) CWCmodel *model;

- (void)addLayer;

@end
