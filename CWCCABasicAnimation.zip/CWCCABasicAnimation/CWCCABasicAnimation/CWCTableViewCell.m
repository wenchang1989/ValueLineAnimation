//
//  CWCTableViewCell.m
//  CWCCABasicAnimation
//
//  Created by CWC on 17/8/22.
//  Copyright © 2017年 . All rights reserved.
//

#import "CWCTableViewCell.h"
#import "CWCCABasicAnimation.h"
#import "CWCmodel.h"

@interface CWCTableViewCell ()<CAAnimationDelegate>

@end

@implementation CWCTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)addLayer{

    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:CGPointMake(0, 22)];
    [path addLineToPoint:CGPointMake(320, 22)];
    
    CAShapeLayer *layer = [CAShapeLayer layer];
    layer.path = path.CGPath;
    //    layer.bounds = CGRectMake(0, 0, 320, 22);
    //    layer.position = CGPointMake(160, 22);
    layer.strokeColor = [UIColor blueColor].CGColor;
    layer.lineWidth = 20.0f;
    self.layer0 = layer;
    [self.contentView.layer addSublayer:layer];
    
    UIBezierPath *path1 = [UIBezierPath bezierPath];
    [path1 moveToPoint:CGPointMake(0, 22)];
    [path1 addLineToPoint:CGPointMake(100, 22)];
    
    CAShapeLayer *layer1 = [CAShapeLayer layer];
    layer1.path = path1.CGPath;
    //    layer1.bounds = CGRectMake(0, 0, 100, 22);
    //    layer1.position = CGPointMake(50, 22);
    layer1.strokeColor = [UIColor redColor].CGColor;
    layer1.lineWidth = 20.0f;
    self.layer1 = layer1;
    [self.contentView.layer addSublayer:layer1];
    
    //    [self addTextLayer:layer];
    
    
    CWCCABasicAnimation *strokeEndAnimation = nil;
    strokeEndAnimation = [CWCCABasicAnimation animationWithKeyPath:@"strokeEnd"];
    strokeEndAnimation.duration = 2.0f;
    strokeEndAnimation.myTag = [NSString stringWithFormat:@"%ld",(long)self.tag0];
    strokeEndAnimation.fromValue = @(0.0f);
    strokeEndAnimation.toValue = @(1.0f);
    strokeEndAnimation.autoreverses = NO; //无自动动态倒退效果
    strokeEndAnimation.delegate = self;
    
    self.animation = strokeEndAnimation;
    
    CABasicAnimation *strokeEndAnimation1 = nil;
    strokeEndAnimation1 = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
    strokeEndAnimation1.duration = 2.0f * 1/3;
    strokeEndAnimation1.fromValue = @(0.0f);
    strokeEndAnimation1.toValue = @(1.0f);
    strokeEndAnimation1.autoreverses = NO; //无自动动态倒退效果
    
    if (self.model.isShow) {
        return;
    }
        [layer addAnimation:strokeEndAnimation forKey: [NSString stringWithFormat: @"strokeEnd%ld",(long)self.tag0]];
        
        [layer1 addAnimation:strokeEndAnimation1 forKey:@"strokeEnd"];
    

    
}

- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag{

    if (self.model.isShow) {
        return;
    }else{
    
        self.model.isShow = YES;
    }
    
    if (self.blockUpdate) {
        self.blockUpdate(self.animation.myTag);
    }
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
