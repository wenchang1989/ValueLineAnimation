//
//  AppDelegate.h
//  CWCCABasicAnimation
//
//  Created by CWC on 17/8/9.
//  Copyright © 2017年 . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

