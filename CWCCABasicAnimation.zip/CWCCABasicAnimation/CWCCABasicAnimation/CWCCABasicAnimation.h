//
//  CWCCABasicAnimation.h
//  CWCCABasicAnimation
//
//  Created by CWC on 17/8/11.
//  Copyright © 2017年 . All rights reserved.
//

#import <QuartzCore/QuartzCore.h>

@interface CWCCABasicAnimation : CABasicAnimation
/**
 *  标记
 */
@property (nonatomic, assign) NSString *myTag;
@end
