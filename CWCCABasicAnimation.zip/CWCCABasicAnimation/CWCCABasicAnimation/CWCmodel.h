//
//  CWCmodel.h
//  CWCCABasicAnimation
//
//  Created by CWC on 17/8/14.
//  Copyright © 2017年 . All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CWCmodel : NSObject

/**
 *  是否显示数字
 */
@property (nonatomic, assign) BOOL isShow;

@end
