//
//  ViewController.m
//  CWCCABasicAnimation
//
//  Created by CWC on 17/8/9.
//  Copyright © 2017年 . All rights reserved.
//

#import "ViewController.h"
#import "CWCCABasicAnimation.h"
#import "CWCmodel.h"
#import "CWCTableViewCell.h"

@interface ViewController ()<UITableViewDelegate, UITableViewDataSource, CAAnimationDelegate>

/**
 *  视图
 */
@property (nonatomic, strong) UITableView *myTableView;
/**
 *  视图数据源
 */
@property (nonatomic, strong) NSMutableArray *sourceArray;

/**
 *  动画数组
 */
@property (nonatomic, strong) NSMutableArray *animationArray;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.title = @"比例条";
    
    self.view.backgroundColor = [UIColor cyanColor];
    
    
    
    for (NSInteger i = 0; i < 20; i ++) {
        CWCmodel *model = [[CWCmodel alloc] init];
        [self.sourceArray addObject:model];
    }
    
//    [self addLayer];
//    [self addAnimation:self.view];
    [self.view addSubview:self.myTableView];
    
    UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 40, 30)];
    [button setTitle:@"刷新" forState:UIControlStateNormal];
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    [button addTarget:self action:@selector(refrashTableView:) forControlEvents:UIControlEventTouchUpInside];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    
    self.myTableView.tableFooterView = [[UIView alloc] init];
    
    
    
}

- (void)viewDidAppear:(BOOL)animated{

    [super viewDidAppear:animated];
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetHeight(self.view.frame)-30, self.view.frame.size.width, 30)];
    view.backgroundColor = [UIColor yellowColor];
    
    [self.view addSubview:view];
    
}

- (void)addLayer{

    CATextLayer *lary = [CATextLayer layer];
    lary.string = @"dasfasa";
    lary.bounds = CGRectMake(0, 0, 320, 20);
//    lary.font = @"HiraKakuProN-W3";//字体的名字 不是 UIFont
    lary.fontSize = 12.f;//字体的大小
//    或者
    //UIFont *font = [UIFont systemFontOfSize:14];
    //    CFStringRef fontCFString = (__bridge CFStringRef)font.fontName;
    //       CGFontRef fontRef = CGFontCreateWithFontName(fontCFString);
    //       textLayer.font = fontRef;
    //       textLayer.fontSize = font.pointSize;
    //       CGFontRelease(fontRef); //与CFRelease的功能相当 当字体的null的时候不会引起程序出错
    
    lary.wrapped = YES;//默认为No.  当Yes时，字符串自动适应layer的bounds大小
    lary.alignmentMode = kCAAlignmentCenter;//字体的对齐方式
    lary.position = CGPointMake(0, 0);//layer在view的位置 适用于跟随摸一个不固定长的的控件后面需要的
    lary.contentsScale = [UIScreen mainScreen].scale;//解决文字模糊 以Retina方式来渲染，防止画出来的文本像素化
    lary.foregroundColor =[UIColor redColor].CGColor;//字体的颜色 文本颜色
    lary.backgroundColor = [UIColor yellowColor].CGColor;
    [self.view.layer addSublayer:lary];
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return self.sourceArray.count;
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    return 44;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

//    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
//    if (!cell) {
     CWCTableViewCell*cell = [[CWCTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
//    }
    cell.model = self.sourceArray[indexPath.row];
//    [[cell.contentView.layer sublayers] makeObjectsPerformSelector:@selector(removeFromSuperlayer)];
//    [[cell.contentView subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    cell.tag0 = indexPath.row;
    [cell addLayer];
    
    
    cell.blockUpdate = ^(NSString *tag){
    
        [self.myTableView beginUpdates];
        [self.myTableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:[tag integerValue] inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
        [self.myTableView endUpdates];
        
    };
    
    
//    [self addAnimation:cell.contentView tag:indexPath.row];
//    [self addTextLayer:cell.contentView.layer tag:indexPath.row];
//    NSInteger tage = indexPath.row;
    CWCmodel *model = self.sourceArray[indexPath.row];
    if (model.isShow) {
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width-20, 12, 20, 20)];
        label.backgroundColor = [UIColor blackColor];
        
        [cell.contentView addSubview:label];
        
        UILabel *labelText = [[UILabel alloc] initWithFrame:CGRectMake(110, 12, 30, 20)];
        labelText.backgroundColor = [UIColor clearColor];
        labelText.text = @"34";
        labelText.textColor = [UIColor whiteColor];
        [cell.contentView addSubview:labelText];
        
    }
    
    return cell;
}



- (void)refrashTableView:(UIButton *)sender{

    [self.myTableView reloadData];
    
}

- (void)addTextLayer:(CALayer *)lay{

    CATextLayer *layer = [CATextLayer layer];
    layer.string = @"12";
    layer.fontSize = 14;
    layer.contentsScale = [UIScreen mainScreen].scale;
    layer.foregroundColor = [UIColor blackColor].CGColor;
    layer.alignmentMode = @"center";
    layer.bounds = CGRectMake(0, 0, 30, 20);
    layer.position = CGPointMake(115, 10);
    layer.hidden = YES;
    [lay addSublayer:layer];
}

- (NSMutableArray *)sourceArray{

    if (!_sourceArray) {
        _sourceArray = [NSMutableArray array];
    }
    return _sourceArray;
}

- (UITableView *)myTableView{

    NSLog(@"======%@",NSStringFromCGSize(self.view.frame.size));
    
    if (!_myTableView) {
        _myTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height - 64) style:UITableViewStylePlain];
        _myTableView.backgroundColor = [UIColor lightGrayColor];
        _myTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        _myTableView.delegate = self;
        _myTableView.dataSource = self;
    }
    return _myTableView;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
